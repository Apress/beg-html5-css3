# Files for Chapter 10
Each file corresponds to the relevant fiddle from [jsfiddle](http://jsfiddle.net)

- `8ZMmT.html`: http://jsfiddle.net/nimbu/8ZMmT/ - Phark Image Replacement
- `pnRb8.html`: http://jsfiddle.net/nimbu/pnRb8/ - Leahy/Langridge Image Replacement
- `Q274j.html`: http://jsfiddle.net/nimbu/Q274j/ - Farhner Image Replacement
- `Q6FBQ.html`: http://jsfiddle.net/nimbu/Q6FBQ/ - JavaScript Image Replacement 
- `Ra6p5.html`: http://jsfiddle.net/nimbu/Ra6p5/ - Gilder/Levin Image Replacement Technique
- `HCgp8.html`: http://jsfiddle.net/nimbu/HCgp8/ - Google Web Font Loader Example
- `mRQpB.html`: http://jsfiddle.net/nimbu/mRQpB/ - Using Font.js when fonts fail to load
- `LrqPb.html`: http://jsfiddle.net/nimbu/LrqPb/ - Fancy Font.js example
- `wcBmD.html`: http://jsfiddle.net/nimbu/wcBmD/ - Fake Bolding of Web Fonts
- `CV2Kt.html`: http://jsfiddle.net/nimbu/CV2Kt/7/ - Vertical Rhythm with PXs
- `eg8D6.html`: http://jsfiddle.net/nimbu/eg8D6/15/ - Vertical Rhythm with EMs
- `BUvMw.html`: http://jsfiddle.net/nimbu/BUvMw/ - Vertical Grid with CSS gradients
- `UrLBk.html`: http://jsfiddle.net/nimbu/UrLBk/ - Word Spacing for Inline Bloc Alignment
- `Rv6vV.html`: http://jsfiddle.net/nimbu/Rv6vV/ - Hyphens with CSS